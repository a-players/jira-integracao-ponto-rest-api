package com.mindproapps.jira.integracaoponto.api;

import com.mindproapps.jira.integracaoponto.service.HorasService;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/horas")
@Produces(MediaType.APPLICATION_JSON)
public class HorasResource {

    private final HorasService horasService;

    @Inject
    public HorasResource(HorasService horasService) {
        this.horasService = horasService;
    }

    @GET
    public Response getHoras() {
        double ponto = horasService.buscarHorasPonto();
        double tempo = horasService.buscarHorasTempo();
        return Response.ok(new ResultadoHoras(ponto, tempo)).build();
    }

    public static class ResultadoHoras {
        public double ponto;
        public double tempo;
        public String status;

        public ResultadoHoras(double ponto, double tempo) {
            this.ponto = ponto;
            this.tempo = tempo;
            this.status = Math.abs(ponto - tempo) < 0.5 ? "ok" : "inconsistente";
        }
    }
}
