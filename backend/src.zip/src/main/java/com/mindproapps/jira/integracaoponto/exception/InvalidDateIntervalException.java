package com.mindproapps.jira.integracaoponto.exception;

public class InvalidDateIntervalException extends RuntimeException {
    public InvalidDateIntervalException(String message) {
        super((message));
    }
}
