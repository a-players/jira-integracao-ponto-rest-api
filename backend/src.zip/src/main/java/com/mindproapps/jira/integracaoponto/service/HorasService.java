package com.mindproapps.jira.integracaoponto.service;

import com.atlassian.sal.api.pluginsettings.PluginSettings;
import com.atlassian.sal.api.pluginsettings.PluginSettingsFactory;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

@Component
public class HorasService {

    private final PluginSettingsFactory pluginSettingsFactory;

    @Inject
    public HorasService(PluginSettingsFactory pluginSettingsFactory) {
        this.pluginSettingsFactory = pluginSettingsFactory;
    }

    public double buscarHorasTempo() {
        try {
            PluginSettings settings = pluginSettingsFactory.createGlobalSettings();
            String tempoApiUrl = "https://api.tempo.io/core/3/worklogs/user/tempo-user-key?from=2025-04-30&to=2025-04-30";
            String tempoApiToken = "Bearer 1aedbdff-377c-43d8-b265-e1b150e4b270";

            URL url = new URL(tempoApiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Authorization", tempoApiToken);

            InputStream response = connection.getInputStream();
            String json = IOUtils.toString(response, StandardCharsets.UTF_8);
            ObjectMapper mapper = new ObjectMapper();
            JsonNode root = mapper.readTree(json);

            double totalSeconds = 0;
            for (JsonNode node : root.get("results")) {
                totalSeconds += node.get("timeSpentSeconds").asDouble();
            }
            return totalSeconds / 3600.0;

        } catch (Exception e) {
            e.printStackTrace();
            return 0.0;
        }
    }

    public double buscarHorasPonto() {
        try {
            PluginSettings settings = pluginSettingsFactory.createGlobalSettings();
            String loginUrlStr = (String) settings.get("integracaoponto.apiLoginUrl");
            String loginJson = (String) settings.get("integracaoponto.apiJsonKey");
            String apiHorasUrl = (String) settings.get("integracaoponto.apiHorasUrl");

            // Realiza o login e recupera token de autenticação
            URL loginUrl = new URL(loginUrlStr);
            HttpURLConnection loginConn = (HttpURLConnection) loginUrl.openConnection();
            loginConn.setRequestMethod("POST");
            loginConn.setRequestProperty("Content-Type", "application/json");
            loginConn.setDoOutput(true);

            try (OutputStream os = loginConn.getOutputStream()) {
                os.write(loginJson.getBytes(StandardCharsets.UTF_8));
            }

            InputStream loginResponse = loginConn.getInputStream();
            String loginResponseJson = IOUtils.toString(loginResponse, StandardCharsets.UTF_8);
            ObjectMapper mapper = new ObjectMapper();
            JsonNode loginRoot = mapper.readTree(loginResponseJson);
            String authToken = loginRoot.get("token").asText();

            // Requisição ao endpoint de ponto
            URL pontoUrl = new URL(apiHorasUrl);
            HttpURLConnection pontoConn = (HttpURLConnection) pontoUrl.openConnection();
            pontoConn.setRequestMethod("GET");
            pontoConn.setRequestProperty("Authorization", "Bearer " + authToken);

            InputStream pontoResponse = pontoConn.getInputStream();
            String pontoJson = IOUtils.toString(pontoResponse, StandardCharsets.UTF_8);
            JsonNode pontoRoot = mapper.readTree(pontoJson);

            return pontoRoot.get("totalHoras").asDouble();

        } catch (Exception e) {
            e.printStackTrace();
            return 0.0;
        }
    }
}
