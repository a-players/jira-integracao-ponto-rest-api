package com.mindproapps.jira.integracaoponto.model.dto.approval;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TimesheetRejectRequestDTO {
    private String reason;
}
