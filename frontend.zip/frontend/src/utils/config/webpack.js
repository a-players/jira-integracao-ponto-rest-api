const config = {
  dist: process.env.DIST ? process.env.DIST : 'LITE'
}

module.exports = config;